package com.william.bibletracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BibletrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
